# Examples

The Prisma examples have been moved to [**`https://www.prisma.io/docs/about/prisma/example-projects`**](https://www.prisma.io/docs/about/prisma/example-projects).
