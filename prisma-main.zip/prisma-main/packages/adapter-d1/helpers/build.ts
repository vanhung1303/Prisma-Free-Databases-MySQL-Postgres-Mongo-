import { build } from '../../../helpers/compile/build'
import { adapterConfig } from '../../../helpers/compile/configs'

void build(adapterConfig)
