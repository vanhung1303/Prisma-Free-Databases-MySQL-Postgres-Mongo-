module.exports = {
  preset: '../../helpers/test/presets/default.js',
}
