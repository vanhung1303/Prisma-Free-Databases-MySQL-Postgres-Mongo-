# Bundle size

This is not a real package and is not meant to be published.

This is a project that is used to measure and track the size of a deployed Prisma Client bundle in edge functions.
