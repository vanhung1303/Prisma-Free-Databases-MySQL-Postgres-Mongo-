module.exports = {
  preset: '../../helpers/test/presets/withSnapshotSerializer.js',
}
