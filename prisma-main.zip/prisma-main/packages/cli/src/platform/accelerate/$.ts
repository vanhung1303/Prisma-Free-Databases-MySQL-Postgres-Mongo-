import { createNamespace } from '../_lib/cli/namespace'

export const $ = createNamespace()
